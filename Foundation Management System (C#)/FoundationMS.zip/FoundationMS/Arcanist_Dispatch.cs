﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoundationMS
{
    public partial class Arcanist_Dispatch : Form
    {
        public Arcanist_Dispatch()
        {
            InitializeComponent();
            displayTable();
        }

        public void displayTable()
        {
            dataGridView1.Rows.Clear();

            Dao dao = new Dao();
            string sql = "select * from Table_Arcanist";
            IDataReader reader = dao.read(sql);

            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader[0], reader[1], reader[2], reader[3], reader[4]);
            }

            reader.Close();
            dao.close();
        }

        private void buttonDispatch_Click(object sender, EventArgs e)
        {
            string arcanistID = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            string arcanistName = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            string status = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            
            if (status == "Unavailable")
            {
                MessageBox.Show("The arcanist is currently unavailable!");
            }
            else
            {
                string sql = $"insert into Table_Dispatch (user_id, arcanist_id,arcanist_name, datetime) values ('{Data.ID}', '{arcanistID}', '{arcanistName}', GETDATE())";
                sql += $"update Table_Arcanist set status = 'Unavailable' where id = '{arcanistID}'";

                Dao dao = new Dao();
                if (dao.execute(sql) > 1) 
                {
                    MessageBox.Show("Successfully dispatched!");
                    displayTable();
                }
                else
                {
                    MessageBox.Show("Failed to dispatch!");
                }

                dao.close();
            }
        }
    }
}
