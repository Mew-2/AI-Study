﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoundationMS
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            if (textBoxAccount.Text != "" && textBoxPassword.Text != "")
            {
                verifyLogin();
            }
            else
            {
                MessageBox.Show("There are empty entries in the input, please re-enter.");
            }
        }

        // verify login
        public void verifyLogin ()
        {
            Dao dao = new Dao();
            string tableName = radioButtonUser.Checked ? "Table_User" : "Table_Admin";
            string sql = $"select * from {tableName} where id = '{textBoxAccount.Text}' and password = '{textBoxPassword.Text}'";
            IDataReader idr = dao.read(sql);

            if (idr.Read())
            {
                Data.ID = idr["id"].ToString();
                Data.password = idr["password"].ToString();

                MessageBox.Show("Login Succeeded");
                this.Hide();
                
                if (radioButtonUser.Checked) 
                {
                    new User().ShowDialog();
                }
                else
                {
                    new Admin().ShowDialog();
                }
                
                this.Show();
            }
            else
            {
                MessageBox.Show("Login failed");
            }

            dao.close();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
