﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoundationMS
{
    public partial class Dispatch_Records : Form
    {
        public Dispatch_Records()
        {
            InitializeComponent();
            displayTable();
        }

        public void displayTable()
        {
            dataGridView1.Rows.Clear();

            Dao dao = new Dao();
            string sql = $"select num, arcanist_id, arcanist_name, datetime from Table_Dispatch where user_id = '{Data.ID}'";
            IDataReader reader = dao.read(sql);

            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader[0], reader[1], reader[2], reader[3]);
            }

            reader.Close();
            dao.close();
        }

        private void buttonMissionComplete_Click(object sender, EventArgs e)
        {
            string num = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            string arcanistID = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();

            string sql = $"delete from Table_Dispatch where num = '{num}';update Table_Arcanist set status = 'Available' where id = {arcanistID}";

            Dao dao = new Dao();
            if (dao.execute(sql) > 1) 
            {
                MessageBox.Show("May the peace be with us.");
                displayTable();
            }
            else
            {
                MessageBox.Show("Operation failed!");
            }

            dao.close();
        }
    }
}
