﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoundationMS
{
    public partial class Edit : Form
    {
        string ID = "";
        public Edit()
        {
            InitializeComponent();
        }

        public Edit(string id, string name, string afflatus, string summon, string status) 
        {
            InitializeComponent();

            ID = textBoxID.Text = id;
            textBoxName.Text = name;
            textBoxAfflatus.Text = afflatus;
            textBoxSummon.Text = summon;    
            textBoxStatus.Text = status;
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            if (textBoxID.Text != "" && textBoxName.Text != "" && textBoxAfflatus.Text != "" && textBoxSummon.Text != "" && textBoxStatus.Text != "")
            {
                Dao dao = new Dao();
                string sql = $"update Table_Arcanist set id = '{textBoxID.Text}', name = '{textBoxName.Text}', afflatus = '{textBoxAfflatus.Text}', summon = '{textBoxSummon.Text}', status = '{textBoxStatus.Text}' where id = '{ID}'";
                int result = dao.execute(sql);
                if (result != 0)
                {
                    MessageBox.Show("Success!");
                }
                else
                {
                    MessageBox.Show("Failed!");
                }
                this.Close();
                dao.close();
            }
            else
            {
                MessageBox.Show("Empty entries are not allowed.");
            }
        }
    }
}
