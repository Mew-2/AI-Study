﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoundationMS
{
    public partial class Add : Form
    {
        public Add()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (textBoxID.Text != "" && textBoxName.Text != "" && textBoxAfflatus.Text != "" && textBoxSummon.Text != "" && textBoxStatus.Text != "")
            {
                Dao dao = new Dao();
                string sql = $"insert into Table_Arcanist values('{textBoxID.Text}', '{textBoxName.Text}', '{textBoxAfflatus.Text}', '{textBoxSummon.Text}', '{textBoxStatus.Text}')";
                int result = dao.execute(sql);
                if (result != 0)
                {
                    MessageBox.Show("Success!");
                }
                else
                {
                    MessageBox.Show("Failed!");
                }

                textBoxClean();
                dao.close();
            }
            else
            {
                MessageBox.Show("Empty entries are not allowed.");
            }
            
        }

        private void buttonClean_Click(object sender, EventArgs e) 
        {
            textBoxClean();
        }

        public void textBoxClean()
        {
            foreach (Control c in this.Controls) 
            {
                if (c is TextBox) 
                {
                    c.Text = "";
                }
            }
        }
    }
}
