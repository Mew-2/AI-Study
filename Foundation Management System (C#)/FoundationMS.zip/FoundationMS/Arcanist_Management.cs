﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoundationMS
{
    public partial class Arcanist_Management : Form
    {
        public Arcanist_Management()
        {
            InitializeComponent();
            displayTable();
        }

        public void displayTable()
        {
            dataGridView1.Rows.Clear();
            
            Dao dao = new Dao();
            string sql = "select * from Table_Arcanist";
            IDataReader reader = dao.read(sql);

            while (reader.Read()) 
            {
                dataGridView1.Rows.Add(reader[0], reader[1], reader[2], reader[3], reader[4]);
            }

            reader.Close();
            dao.close();
        }

        // 委托事件
        private void formClosedDelegate(object sender, FormClosedEventArgs e)
        {
            displayTable();
        }


        private void buttonAdd_Click(object sender, EventArgs e)
        {
            Add add = new Add();
            add.FormClosed += formClosedDelegate;
            add.Show();
        }

        private void buttonDelete_Click(object sender, EventArgs e) 
        {
            try
            {
                string ID = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                string sql = $"delete from Table_Arcanist where id = '{ID}'";
                DialogResult dialogResult = MessageBox.Show("Are you sure to delete?", "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                if (dialogResult == DialogResult.OK)
                {
                    Dao dao = new Dao();
                    int result = dao.execute(sql);

                    if (result != 0)
                    {
                        MessageBox.Show("Success!");
                        displayTable();
                    }
                    else
                    {
                        MessageBox.Show("Failed!");
                    }

                    dao.close();
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Please select the record to delete from the table first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            try
            {
                string id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                string name = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                string afflatus = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                string summon = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                string status = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();

                Edit edit = new Edit(id, name, afflatus, summon, status);
                edit.FormClosed += formClosedDelegate;
                edit.Show();
            }
            catch (Exception)
            {

                MessageBox.Show("Error");
            }
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            displayTable();
        }

        private void buttonAfflatus_Click(object sender, EventArgs e)
        {
            if (textBoxAfflatus.Text != "")
            {
                dataGridView1.Rows.Clear();

                Dao dao = new Dao();
                string sql = $"select * from Table_Arcanist where \"afflatus\" = '{textBoxAfflatus.Text.ToLower()}'";
                IDataReader reader = dao.read(sql);

                while (reader.Read())
                {
                    dataGridView1.Rows.Add(reader[0], reader[1], reader[2], reader[3], reader[4]);
                }

                reader.Close();
                dao.close(); 
            }
            else
            {
                MessageBox.Show("Search term cannot be empty!");
            }
        }

        private void buttonName_Click(object sender, EventArgs e)
        {
            if (textBoxName.Text != "")
            {
                dataGridView1.Rows.Clear();

                Dao dao = new Dao();
                string sql = $"select * from Table_Arcanist where \"name\" like '%{textBoxName.Text.ToLower()}%'";
                IDataReader reader = dao.read(sql);

                while (reader.Read())
                {
                    dataGridView1.Rows.Add(reader[0], reader[1], reader[2], reader[3], reader[4]);
                }

                reader.Close();
                dao.close(); 
            }
            else
            {
                MessageBox.Show("Search term cannot be empty!");
            }
        }
    }
}
