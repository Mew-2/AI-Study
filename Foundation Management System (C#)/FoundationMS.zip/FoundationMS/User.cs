﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoundationMS
{
    public partial class User : Form
    {
        public User()
        {
            InitializeComponent();
        }

        private void arcanistDispatchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Arcanist_Dispatch arcanist_Dispatch = new Arcanist_Dispatch();
            arcanist_Dispatch.Show();
        }

        private void dispatchRecordsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Dispatch_Records dispatch_Records = new Dispatch_Records();
            dispatch_Records.Show();
        }
    }
}
