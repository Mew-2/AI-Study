﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoundationMS
{
    class Data
    {
        public static string ID = "", password = "";
    }
}
