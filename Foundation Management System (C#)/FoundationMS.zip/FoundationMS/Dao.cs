﻿using System.Data.SqlClient;

namespace FoundationMS
{
    class Dao
    {
        SqlConnection connection;
        public SqlConnection connect()
        {
            string str = @"Data Source = DESKTOP-KRM06OL; Initial Catalog = FoundationDB; Integrated Security = True";
            connection = new SqlConnection(str);
            connection.Open();
            return connection;
        }

        public SqlCommand command(string sql)
        {
            return new SqlCommand(sql, connect());
        }

        public int execute(string sql) 
        {
            return command(sql).ExecuteNonQuery();
        }

        public SqlDataReader read(string sql) 
        {
            return command(sql).ExecuteReader();
        }

        public void close() 
        {
            connection.Close();
        }
    }
}
